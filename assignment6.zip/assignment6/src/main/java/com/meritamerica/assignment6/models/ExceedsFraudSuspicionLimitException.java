package com.meritamerica.assignment6.models;

public class ExceedsFraudSuspicionLimitException extends Exception {
	public ExceedsFraudSuspicionLimitException(String message) {
		super(message);
	}
}
